"use strict";
var binnacle = binnacle || {};

binnacle.resources = {
	"tasks" : {
		"Audit.bSave" : "Guardar",
		"Audit.lAuditCriteria" : "Criterio de auditoría"
	}  
}